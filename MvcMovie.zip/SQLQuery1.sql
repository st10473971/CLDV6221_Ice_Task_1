﻿UPDATE Movie
SET Rating = 'PG'
WHERE Rating IS NULL;

